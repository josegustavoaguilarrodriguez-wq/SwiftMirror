package com.swiftmirror.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

class MirrorService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var server: ServerSocket? = null
    @Volatile private var running = false
    private val latestJpeg = AtomicReference<ByteArray?>(null)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Swift Mirror activo")
            .setContentText("Compartiendo pantalla por Wi-Fi")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (!running && intent != null) {
            val resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            val data = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra("projectionData", Intent::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra("projectionData")
            if (data != null && resultCode == Activity.RESULT_OK) startProjection(resultCode, data)
        }
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
        val width = (metrics.widthPixels * 0.75f).toInt().coerceAtLeast(480)
        val height = (metrics.heightPixels * 0.75f).toInt().coerceAtLeast(800)
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ imageReader ->
            var image: Image? = null
            try {
                image = imageReader.acquireLatestImage()
                if (image != null) latestJpeg.set(imageToJpeg(image))
            } catch (_: Exception) {
            } finally {
                image?.close()
            }
        }, null)

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, null)
        virtualDisplay = projection?.createVirtualDisplay(
            "SwiftMirrorDisplay", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, null
        )
        running = true
        startHttpServer()
    }

    private fun imageToJpeg(image: Image): ByteArray {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val bitmap = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        bitmap.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
        val out = ByteArrayOutputStream()
        cropped.compress(Bitmap.CompressFormat.JPEG, 65, out)
        bitmap.recycle()
        cropped.recycle()
        return out.toByteArray()
    }

    private fun startHttpServer() {
        thread(name = "SwiftMirrorHTTP") {
            try {
                server = ServerSocket(8080)
                while (running) {
                    val client = server!!.accept()
                    thread { handleClient(client) }
                }
            } catch (_: Exception) {
                // Socket closed during shutdown.
            }
        }
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            try {
                client.soTimeout = 10000
                val input = client.getInputStream().bufferedReader()
                val request = input.readLine() ?: return
                while (input.readLine()?.isNotEmpty() == true) { }
                val path = request.split(" ").getOrNull(1) ?: "/"
                val out = client.getOutputStream()
                if (path == "/stream") streamMjpeg(out) else servePage(out)
            } catch (_: Exception) { }
        }
    }

    private fun servePage(out: OutputStream) {
        val html = """HTTP/1.1 200 OK\r
Content-Type: text/html; charset=utf-8\r
Connection: close\r
\r
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;background:#101827;color:white;font-family:sans-serif;text-align:center">
<h3>Swift Mirror</h3><img src="/stream" style="width:100%;height:auto">
<p>Transmisión local desde el teléfono</p></body></html>"""
        out.write(html.toByteArray(Charsets.UTF_8))
        out.flush()
    }

    private fun streamMjpeg(out: OutputStream) {
        out.write(("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray())
        out.flush()
        while (running) {
            val frame = latestJpeg.get()
            if (frame != null) {
                out.write("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${frame.size}\r\n\r\n".toByteArray())
                out.write(frame)
                out.write("\r\n".toByteArray())
                out.flush()
            }
            Thread.sleep(100)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Swift Mirror", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL = "swift_mirror_channel"
        private const val NOTIFICATION_ID = 17
    }
}

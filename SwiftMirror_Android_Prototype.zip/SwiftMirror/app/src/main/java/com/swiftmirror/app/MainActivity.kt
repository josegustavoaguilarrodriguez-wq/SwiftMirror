package com.swiftmirror.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.content.Context
import android.net.wifi.WifiManager
import android.text.format.Formatter

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val requestCode = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 40, 36, 40)
            setBackgroundColor(Color.rgb(16, 24, 39))
        }
        val title = TextView(this).apply {
            text = "SWIFT MIRROR"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Transmisor inalámbrico de pantalla"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Listo para iniciar"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 22)
        }
        val start = Button(this).apply {
            text = "INICIAR TRANSMISIÓN"
            setOnClickListener { requestCapture() }
        }
        val stop = Button(this).apply {
            text = "DETENER"
            setOnClickListener {
                stopService(Intent(this@MainActivity, MirrorService::class.java))
                status.text = "Transmisión detenida"
            }
        }
        val note = TextView(this).apply {
            text = "La transmisión genera una dirección local en el teléfono. El dispositivo receptor debe poder abrir video MJPEG desde esa dirección."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }
        listOf(title, subtitle, status, start, stop, note).forEach {
            layout.addView(it, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 12 })
        }
        setContentView(layout)
    }

    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCode)
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, MirrorService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("projectionData", data)
            }
            startForegroundService(service)
            val ip = getWifiIp()
            status.text = "Transmisión iniciada\nAbrir en receptor:\nhttp://$ip:8080/"
        } else {
            status.text = "Permiso de captura cancelado"
        }
    }

    private fun getWifiIp(): String {
        return try {
            val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            Formatter.formatIpAddress(wifi.connectionInfo.ipAddress).ifBlank { "IP_NO_DISPONIBLE" }
        } catch (_: Exception) { "IP_NO_DISPONIBLE" }
    }
}

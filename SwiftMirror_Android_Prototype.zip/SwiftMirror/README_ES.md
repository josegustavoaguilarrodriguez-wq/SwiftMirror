# Swift Mirror — prototipo 0.1

Aplicación Android experimental para capturar la pantalla del teléfono y servirla como video MJPEG en la red Wi-Fi local.

## Importante: compatibilidad con AV-1297W
Esta aplicación es únicamente el **transmisor**. Para ver la imagen, el receptor debe poder abrir una URL HTTP local y mostrar un flujo MJPEG. No hay confirmación de que la radio AV-1297W/AM9X tenga navegador o receptor MJPEG integrado. Android Auto no convierte automáticamente la radio en un receptor de este flujo.

Por tanto, este prototipo no promete duplicación directa en la radio sin accesorios. Primero hay que probar si el firmware de la radio puede acceder al flujo.

## Abrir el proyecto
1. Instala Android Studio.
2. Abre la carpeta `SwiftMirror`.
3. Espera la sincronización de Gradle.
4. Conecta el Galaxy S23 Ultra por USB y activa Depuración USB.
5. Ejecuta la app desde Android Studio.

## Uso
1. Conecta el teléfono a la misma red Wi-Fi que el receptor.
2. Abre Swift Mirror y pulsa **INICIAR TRANSMISIÓN**.
3. Acepta el permiso de captura de pantalla de Android.
4. La aplicación mostrará una URL similar a `http://192.168.1.20:8080/`.
5. Abre esa URL desde un navegador o receptor compatible conectado a la misma red.

## Limitaciones de esta versión
- Prototipo de desarrollo; no es una APK compilada.
- No incorpora receptor para la radio.
- La calidad y fluidez dependen del Wi-Fi y del dispositivo receptor.
- Android muestra un aviso de captura y mantiene una notificación mientras se transmite.
- No está diseñada para reproducir contenido protegido por DRM.
- Usar video únicamente con el vehículo estacionado.

## Próxima etapa
Investigar el firmware y las interfaces disponibles en la AV-1297W para comprobar si puede abrir una URL local o recibir MJPEG/Miracast. Si no puede, la condición de no usar accesorios adicionales puede hacer técnicamente imposible la duplicación.
